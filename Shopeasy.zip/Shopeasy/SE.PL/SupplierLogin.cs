﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SE.Entity;
using SE.Exception;
using SE.BL;

namespace SE.PL
{
    
    public partial class SupplierLogin : Form
    {
        
        public static int SID;
        public SupplierLogin()
        {
            InitializeComponent();
        }
        CustomValidation cv = new CustomValidation();
        private void btnSupplierLogin_Click(object sender, EventArgs e)
        {
            int Sid=Convert.ToInt32(txtSupUserName.Text);
            string Spass=txtSupPassword.Text;
            bool auth = cv.authSupplier(Sid, Spass);
            if (auth)
            {
                SID = Sid;
                Supplier sup = new Supplier();
                sup.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
                txtSupUserName.Text = "";
                txtSupPassword.Text = "";
                txtSupUserName.Focus();
            }
            
        }

   
    }
}
