﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.BL;

namespace SE.PL
{
    public partial class Login : Form
    {
        public static string user=null;
        public static string Uid = null;
        public Login()
        {
            InitializeComponent();
        }
        CustomValidation cv = new CustomValidation();
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string uname = txtUserName.Text;
            string pass = txtPassword.Text;
            DataTable dt = new DataTable();
            dt = cv.searchCustomer(uname,pass);
            if (dt.Rows.Count>0)
            {
                user = txtUserName.Text;
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                Uid = ds.Tables[0].Rows[0][0].ToString();
                this.Hide();
                HomePage hp = new HomePage();
                hp.Show();
            }
            else
            {
                MessageBox.Show("Please enter correct username and password");
                txtUserName.Text = "";
                txtPassword.Text = "";
                txtUserName.Focus();
            }
        }

        private void linlabRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registration rg = new Registration();
            rg.Show();
            this.Hide();
        }

        private void linklblAdmin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AdminLogin al = new AdminLogin();
            al.Show();
            this.Hide();
        }

        private void Login_Activated(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtUserName.Focus();
        }

        private void linklblSupplier_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SupplierLogin sl = new SupplierLogin();
            sl.Show();
            this.Hide();
        }
    }
}
