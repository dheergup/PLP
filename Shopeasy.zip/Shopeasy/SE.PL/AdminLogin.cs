﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SE.PL
{
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Admin ad = new Admin();
            string aID = txtAdminName.Text;
            string aPassword = txtAdminPassword.Text;

            if (aID == "Admin" && aPassword == "Welcome@123")
            {
                ad.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Enter Correct Credentials");
                txtAdminName.Text = "";
                txtAdminPassword.Text = "";
                txtAdminName.Focus();
            }
            
        }

        private void AdminLogin_Activated(object sender, EventArgs e)
        {
            txtAdminName.Text = "";
            txtAdminPassword.Text = "";
            txtAdminName.Focus();
        }
    }
}
