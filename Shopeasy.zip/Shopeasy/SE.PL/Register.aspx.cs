﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.DAL;

namespace SE.PL
{
    public partial class Register : System.Web.UI.Page
    {
        CustomerOperations cp = new CustomerOperations();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            Customer cust = new Customer();
            try
            {
                cust.CFName = txtFName.Text;
                cust.CLName = txtLName.Text;
                cust.Email = txtEmail.Text;
                cust.Mobile = txtMobile.Text;
                cust.Pass = txtPassword.Text;
                cust.UserID = txtUID.Text;
                bool flag = cp.addCustomer(cust);
                if (flag)
                {
                    string message = "You have successfully registered";
                    string url = "/Login.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }
            }
            catch (CustomerException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}