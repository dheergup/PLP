﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SE.PL.Supplier
{
    public partial class SupplierMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["SID"] == null || Session["SID"] == String.Empty)
            {
                Response.Redirect("/Supplier/SupplierLogin.aspx");
            }
            else
            {
                Label1.Text = Session["SID"].ToString();
            }
        }

        protected void lnbtnLogout_Click(object sender, EventArgs e)
        {
            Session["SID"] = null;
            Response.Redirect("/Supplier/SupplierLogin.aspx");
        }
    }
}