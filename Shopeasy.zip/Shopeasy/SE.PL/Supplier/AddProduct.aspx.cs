﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.IO;

namespace SE.PL.Supplier
{
    public partial class AddProduct : System.Web.UI.Page
    {
        SupplierOperations sop = new SupplierOperations();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["SID"] == null || Session["SID"] == String.Empty)
            {
                Response.Redirect("/Supplier/SupplierLogin.aspx");
            }
            else
            {
                txtSupplierID.Text = Session["SID"].ToString();
                Master.User = Session["SID"].ToString();
                try
                {
                    DataTable table = new DataTable();
                    table = sop.getCategory();
                    DataSet ds = new DataSet();
                    ds.Tables.Add(table);
                    for (int i = 0; i < table.Rows.Count; i++)
                    {
                        ddlCategory.Items.Add(ds.Tables[0].Rows[i][1].ToString() + "-" + ds.Tables[0].Rows[i][2].ToString());
                    }
                }
                catch (SupplierException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
            
      
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                Product prod = new Product();
                prod.ProductName = txtProductName.Text;
                prod.SupplierID = Convert.ToInt32(txtSupplierID.Text);
                prod.CategoryID = ddlCategory.SelectedIndex + 100001;
                prod.Units = Convert.ToInt32(txtUnits.Text);
                prod.UnitPrice = Convert.ToInt32(txtUnitPrice.Text);
                prod.MRP = Convert.ToInt32(txtMRP.Text);
                prod.Discount = Convert.ToDecimal(txtDiscount.Text);
                prod.Ranking = Convert.ToInt32(txtRanking.Text);
                prod.ProductDesc = txtProdDesc.Text;
                prod.DOM = DateTime.Now;
                Stream fs = FImageUpload.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                byte[] bytes = br.ReadBytes((Int32)fs.Length);
                prod.Picture = bytes;
                if (ddlCategory.SelectedIndex <= 3)
                    prod.CategorygDesc = "Electronics";
                else if (ddlCategory.SelectedIndex <= 7 && ddlCategory.SelectedIndex >= 4)
                    prod.CategorygDesc = "Home appliances";
                else if (ddlCategory.SelectedIndex <= 11 && ddlCategory.SelectedIndex >= 8)
                    prod.CategorygDesc = "Men";
                else if (ddlCategory.SelectedIndex <= 15 && ddlCategory.SelectedIndex >= 12)
                    prod.CategorygDesc = "Women";
                bool flag=sop.addProduct(prod);
                if (flag)
                {
                    string message = "Product Added Successfully";
                    string url = "/Supplier/AddProduct.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }

            }
            catch (SupplierException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}