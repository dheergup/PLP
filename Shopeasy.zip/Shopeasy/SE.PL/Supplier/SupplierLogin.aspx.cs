﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.Data;
using System.Data.SqlClient;
namespace SE.PL.Supplier
{
    public partial class SupplierLogin : System.Web.UI.Page
    {
        SupplierOperations sop = new SupplierOperations();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            int Sid = Convert.ToInt32(txtSupUsername.Text);
            string Spass = txtSupPassword.Text;
            bool auth = sop.authSupplier(Sid, Spass);
            if (auth)
            {
                Session["SID"] = Sid;
                Response.Redirect("/Supplier/AddProduct.aspx");
            }
            else
            {
                string message = "Enter Correct Credentials.";
                string url = "/Supplier/SupplierLogin.aspx";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += url;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
            }
        }
    }
}