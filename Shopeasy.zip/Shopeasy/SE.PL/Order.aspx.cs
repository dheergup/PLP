﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.Data;
using System.Data.SqlClient;
namespace SE.PL
{
    public partial class Order : System.Web.UI.Page
    {
        public static int quantity = 0;
        CustomerOperations cp = new CustomerOperations();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null || Session["User"] == String.Empty)
            {
                Master.Login = true;
                Master.Logout = false;
            }
            else
            {
                Master.UserName = Session["User"].ToString();
                Master.Login = false;
                Master.Logout = true;
                try
                {
                    DataTable tb = new DataTable();
                    tb = cp.getProductByName(Session["ProductName"].ToString());
                    DataSet ds = new DataSet();
                    ds.Tables.Add(tb);
                    txtPID.Text = ds.Tables[0].Rows[0][0].ToString();
                    txtPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                    quantity = Convert.ToInt32(ds.Tables[0].Rows[0][4].ToString());
                    txtBillDate.Text = DateTime.Now.ToString();
                }
                catch (CustomerException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            try
            {

                Entity.Order od = new Entity.Order();
                od.ODate = DateTime.Now;
                od.CustomerID = Convert.ToInt32(Session["Uid"].ToString());
                od.ProductID = Convert.ToInt32(txtPID.Text);
                od.Price = Convert.ToInt32(txtPrice.Text);
                od.Quantity = Convert.ToInt32(txtQuantity.Text);
                od.Total = Convert.ToInt32(txtTotal.Text);
                od.BARoomNo = txtBRoomNo.Text;
                od.BACity = txtBCity.Text;
                od.BAState = ddBState.SelectedItem.Text;
                od.BAPincode = txtBPincode.Text;
                od.SARoomNo = txtSRoomNo.Text;
                od.SACity = txtSCity.Text;
                od.SAState = ddSState.SelectedItem.Text;
                od.SAPincode = txtSPincode.Text;

                bool flag = cp.addOrder(od);

                if (flag)
                {

                    bool flag1 = cp.UpdateProduct(Convert.ToInt32(txtQuantity.Text), Convert.ToInt32(txtPID.Text));
                    if (flag1)
                    {
                        Session["ProductName"] = "";
                        string message = "Order Added Successfully.";
                        string url = "Homepage.aspx";
                        string script = "window.onload = function(){ alert('";
                        script += message;
                        script += "');";
                        script += "window.location = '";
                        script += url;
                        script += "'; }";
                        ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                    }
                }
                else
                {
                    string message = "Order Not Placed";
                    string url = "Homepage.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }
            }
            catch (CustomerException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            if (quantity < Convert.ToInt32(txtQuantity.Text))
            {
                Response.Write("<script>alert('This many products are not available');</script>");
                txtQuantity.Text = "";
                txtQuantity.Focus();
            }
            else
            {
                txtTotal.Text = ((Convert.ToInt32(txtPrice.Text)) * (Convert.ToInt32(txtQuantity.Text))).ToString();
            }
        }

        protected void txtBRoomNo_TextChanged(object sender, EventArgs e)
        {
            txtSRoomNo.Text = txtBRoomNo.Text;
        }

        protected void txtBCity_TextChanged(object sender, EventArgs e)
        {
            txtSCity.Text = txtBCity.Text;
        }

        protected void ddBState_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddSState.SelectedIndex = ddBState.SelectedIndex;
        }

        protected void txtBPincode_TextChanged(object sender, EventArgs e)
        {
            txtSPincode.Text = txtBPincode.Text;
        }
    }
}