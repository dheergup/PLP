﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Entity
{
    /// <summary>
    /// Employee ID : 121639
    /// Employee Name : Aishwarya Dudgol
    /// Description : This Class has Structure of Customer Class
    /// Date Of Creation : 4th April,2017
    /// </summary>
    
    public class Customer
    {
        public int CustomerID { get; set; }
        public string CFName { get; set; }
        public string CLName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string UserID { get; set; }
        public string Pass { get; set; }
    }
}
