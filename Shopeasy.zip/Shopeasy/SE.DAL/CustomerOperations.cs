﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
    
    public class CustomerOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;

        //Method For Adding Customers
        public bool addCustomer(Customer cust)
        {
            bool customerAdded = false;
            try
            {
                cmd.CommandText = "[EC].[addCustomer]";

                cmd.Parameters.AddWithValue("@CFName", cust.CFName);
                cmd.Parameters.AddWithValue("@CLName", cust.CLName);
                cmd.Parameters.AddWithValue("@Email", cust.Email);
                cmd.Parameters.AddWithValue("@Mobile", cust.Mobile);
                cmd.Parameters.AddWithValue("@UID", cust.UserID);
                cmd.Parameters.AddWithValue("@Pass", cust.Pass);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    customerAdded = true;
                }
                cmd.Connection.Close();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return customerAdded;
        }



        //Method For authenticating Customers
        public DataTable authCustomer(string CID, string pass)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[authenticateCustomer]";
                cmd.Parameters.AddWithValue("@UID", CID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }
       
        //Method For Adding Order Placed By Customer Into Order table
        public bool addOrder(Order ord)
        {
            bool orderAdded = false;
            int result = 0;
            try
            {

                cmd.CommandText = "[EC].[Orderadd]";
                cmd.Parameters.Add("@ODate", SqlDbType.DateTime).Value = ord.ODate;
                cmd.Parameters.Add("@CID", SqlDbType.Int).Value = ord.CustomerID;
                cmd.Parameters.Add("@PID", SqlDbType.Int).Value = ord.ProductID;
                cmd.Parameters.Add("@Price", SqlDbType.Int).Value = ord.Price;
                cmd.Parameters.Add("@Quantity", SqlDbType.Int).Value = ord.Quantity;
                cmd.Parameters.Add("@Total", SqlDbType.Int).Value = ord.Total;
                cmd.Parameters.Add("@BARNo", SqlDbType.NVarChar,100).Value = ord.BARoomNo;
                cmd.Parameters.Add("@BACity", SqlDbType.NVarChar, 100).Value = ord.BACity;
                cmd.Parameters.Add("@BAState", SqlDbType.NVarChar, 100).Value = ord.BAState;
                cmd.Parameters.Add("@BAPincode", SqlDbType.NVarChar, 100).Value = ord.BAPincode;
                cmd.Parameters.Add("@SARNo", SqlDbType.NVarChar, 100).Value = ord.SARoomNo;
                cmd.Parameters.Add("@SACity", SqlDbType.NVarChar, 100).Value = ord.SACity;
                cmd.Parameters.Add("@SAState", SqlDbType.NVarChar, 100).Value = ord.SAState;
                cmd.Parameters.Add("@SPincode", SqlDbType.NVarChar, 100).Value = ord.SAPincode;
                cmd.Connection.Open();
                result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    orderAdded = true;
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return orderAdded;
        }

       
        
        //Method For Searching Category Of a Product
        public DataTable searchCategory(string type)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[searchCategory]";
                cmd.Parameters.AddWithValue("@Type", type);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }



        //Method For Searching a Product Depending On Category And Sub-Category
        public DataTable searchProduct(string type, string type1)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[searchProduct]";
                cmd.Parameters.AddWithValue("@Type", type);
                cmd.Parameters.AddWithValue("@Type1", type1);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }


        //public bool SearchProduct(String ProdName)
        //{
        //    bool ProdFound = false;
        //    try
        //    {
        //        cmd.CommandText = "EC.searchProduct";
        //        cmd.Parameters.AddWithValue("@Sid", ProdName);
        //        cmd.Connection.Open();
        //        int result = cmd.ExecuteNonQuery();
        //        if (result > 0)
        //        {
        //            ProdFound = true;
        //        }
        //        cmd.Connection.Close();

        //    }
        //    catch (CustomerException ex)
        //    {

        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw;
        //    }
        //    return ProdFound;
        //}

        //Method For Fetching a particular Product Details Depending on Product Selected  
        public DataTable getProductByName(string type)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[getProductByName]";
                cmd.Parameters.AddWithValue("@Type", type);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }


        //Method For Fetching All Categories
        //public DataTable getCategory()
        //{
        //    table = new DataTable();
        //    try
        //    {
        //        cmd.CommandText = "[EC].[getCategory]";
        //        cmd.Connection.Open();
        //        dr = cmd.ExecuteReader();
        //        table.Load(dr);
        //        cmd.Connection.Close();
        //    }
        //    catch (CustomerException ex)
        //    {
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw;
        //    }

        //    return table;
        //}

        public DataTable searchProductByLike(string pattern)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "ec.searchProductByLike";
                cmd.Parameters.AddWithValue("@Pattern", pattern);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }
        public DataTable searchCustomer(string CID, string pass)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText="[EC].[authenticateCustomer]";
                cmd.Parameters.AddWithValue("@UID", CID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();
            }
            catch (CustomerException ex)
            {

                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }

        public bool UpdateProduct(int quantity,int Pid)
        {
            bool productUpdated = false;
            int result = 0;
            try
            {

                cmd.CommandText = "[EC].[updateProduct]";
                cmd.Parameters.AddWithValue("@Type1",quantity);
                cmd.Parameters.AddWithValue("@Type", Pid);
                cmd.Connection.Open();
                result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productUpdated = true;
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productUpdated;
        }
    }
}
