﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Exception
{
        /// <summary>
        /// Employee ID : 
        /// Employee Name : 
        /// Description : 
        /// </summary>

       public class SupplierException: ApplicationException
       {
            public SupplierException()
                : base()
            { }

            public SupplierException(string message)
                : base(message)
            { }
        }
    }

