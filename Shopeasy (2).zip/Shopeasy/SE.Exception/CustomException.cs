﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Exception
{
    /// <summary>
    /// Employee ID : 121639
    /// Employee Name : Aishwarya Dudgol
    /// Description : Custom Exception Class to handle all Exceptions
    /// </summary>
    
    public class CustomException: ApplicationException
    {
        public CustomException()
            : base()
        { }

        public CustomException(string message)
            : base(message)
        { }
    }
}
