﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Entity
{
    /// <summary>
    /// Employee ID : 121639
    /// Employee Name : Aishwarya Dudgol
    /// Description : This Class has Structure of Order Class
    /// Date Of Creation : 4th April,2017
    /// </summary>

    public class Order
    {
       public DateTime ODate { get; set; }
       public int CustomerID { get; set; }
       public int ProductID { get; set; }
       public int Price { get; set; }
       public int Quantity { get; set; }
       public int Total { get; set; }
       public string BARoomNo { get; set; }
       public string BACity { get; set; }
       public string BAState { get; set; }
       public string BAPincode { get; set; }
       public string SARoomNo { get; set; }
       public string SACity { get; set; }
       public string SAState { get; set; }
       public string SAPincode { get; set; }
     }
   
}
