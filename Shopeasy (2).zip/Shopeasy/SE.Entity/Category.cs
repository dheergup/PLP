﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Entity
{
    /// <summary>
    /// Employee ID : 121639
    /// Employee Name : Aishwarya Dudgol
    /// Description : This Class has Structure of Category Class
    /// Date Of Creation : 4th April,2017
    /// </summary>
    
    public class Category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string CategoryDesc { get; set; }
    }
}
