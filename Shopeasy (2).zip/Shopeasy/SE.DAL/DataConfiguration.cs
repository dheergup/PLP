﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
    
    public class DataConfiguration
    {
        //Method For Creating Connection TO database
        public static SqlCommand CreateCommand()
        {
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                con = new SqlConnection();
                con.ConnectionString = ConfigurationManager.ConnectionStrings["ShopEasy"].ConnectionString;

                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cmd;
        }
    }
}
