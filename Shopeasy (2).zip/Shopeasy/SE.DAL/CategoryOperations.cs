﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
    
    public class CategoryOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;

        //Method For Searching Category Of a Product
        public DataTable searchCategory(string type)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[searchCategory]";
                cmd.Parameters.AddWithValue("@Type", type);

                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }

        //Method For Fetching All Categories
        //public DataTable getCategory()
        //{
        //    table = new DataTable();
        //    try
        //    {
        //        cmd.CommandText = "[EC].[getCategory]";
        //        cmd.Connection.Open();
        //        dr = cmd.ExecuteReader();
        //        table.Load(dr);
        //        cmd.Connection.Close();
        //    }
        //    catch (CustomException ex)
        //    {
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw;
        //    }

        //    return table;
        //}
    }
}
