﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
   
    public class CustomerOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;

        //Method For Adding Customers
        public bool addCustomer(Customer cust)
        {
            bool customerAdded = false;
            try
            {
                cmd.CommandText = "[EC].[addCustomer]";

                cmd.Parameters.AddWithValue("@CFName", cust.CFName);
                cmd.Parameters.AddWithValue("@CLName", cust.CLName);
                cmd.Parameters.AddWithValue("@Email", cust.Email);
                cmd.Parameters.AddWithValue("@Mobile", cust.Mobile);
                cmd.Parameters.AddWithValue("@UID", cust.UserID);
                cmd.Parameters.AddWithValue("@Pass", cust.Pass);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    customerAdded = true;
                }
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return customerAdded;
        }

        //Method For Searching Customers
        public DataTable searchCustomer(string CID, string pass)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[authenticateCustomer]";
                cmd.Parameters.AddWithValue("@UID", CID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }

        //Method For Displaying All Customers
        public DataTable viewCustomer()
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "EC.viewCustomer";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }
    }
}
