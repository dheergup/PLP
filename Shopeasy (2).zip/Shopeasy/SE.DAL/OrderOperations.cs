﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{

    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
  
    public class OrderOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;

        //Method For Adding Order Placed By Customer Into Order table
        public bool addOrder(Order ord)
        {
            bool orderAdded = false;
            try
            {
                cmd.CommandText = "[EC].[addOrder]";

                cmd.Parameters.AddWithValue("@ODate", ord.ODate);
                cmd.Parameters.AddWithValue("@CID", ord.CustomerID);
                cmd.Parameters.AddWithValue("@PID", ord.ProductID);
                cmd.Parameters.AddWithValue("@Price", ord.Price);
                cmd.Parameters.AddWithValue("@Quantity", ord.Quantity);
                cmd.Parameters.AddWithValue("@Total", ord.Total);
                cmd.Parameters.AddWithValue("@BARNo", ord.BARoomNo);
                cmd.Parameters.AddWithValue("@BACity", ord.BACity);
                cmd.Parameters.AddWithValue("@BAState", ord.BAState);
                cmd.Parameters.AddWithValue("@BAPincode", ord.BAPincode);
                cmd.Parameters.AddWithValue("@SARNo", ord.SARoomNo);
                cmd.Parameters.AddWithValue("@SACity", ord.SACity);
                cmd.Parameters.AddWithValue("@SAState", ord.SAState);
                cmd.Parameters.AddWithValue("@SPincode", ord.SAPincode);

                cmd.Connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    orderAdded = true;
                }
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return orderAdded;
        }

        //Method For Viewing All Orders Placed By Customers 
        public DataTable viewOrder()
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "EC.viewOrder";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }

    }
}
