﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
    
    public class SupplierOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;


        //Method for Authenticating Supplier 
        public bool authSupplier(int SID, string pass)
        {
            bool SupplierAuthenticated = false;
            try
            {
                cmd.CommandText = "[EC].[authenticateSupplier]";
                cmd.Parameters.AddWithValue("@SID", SID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                cmd.Connection.Open();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    SupplierAuthenticated = true;
                }
                cmd.Connection.Close();
            }
            catch (SupplierException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return SupplierAuthenticated;
        }



        //Method For Adding Products
        public bool addProduct(Product prd)
        {
            bool productAdded = false;
            try
            {
                cmd.CommandText = "EC.addProduct";
                cmd.Parameters.AddWithValue("@PName", prd.ProductName);
                cmd.Parameters.AddWithValue("@SID", prd.SupplierID);
                cmd.Parameters.AddWithValue("@CID", prd.CategoryID);
                cmd.Parameters.AddWithValue("@Units", prd.Units);
                cmd.Parameters.AddWithValue("@UPrice", prd.UnitPrice);
                cmd.Parameters.AddWithValue("@MRP", prd.MRP);
                cmd.Parameters.AddWithValue("@Discount", prd.Discount);
                cmd.Parameters.AddWithValue("@Picture", prd.Picture);
                cmd.Parameters.AddWithValue("@Rank", prd.Ranking);
                cmd.Parameters.AddWithValue("@PDesc", prd.ProductDesc);
                cmd.Parameters.AddWithValue("@DOM", prd.DOM);
                cmd.Parameters.AddWithValue("@CDesc", prd.CategorygDesc);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productAdded = true;
                }
                cmd.Connection.Close();
            }
            catch (SupplierException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productAdded;
        }


        //Method For Updating Product Details
        public bool updateProduct(Product prd)
        {
            bool productUpdated = false;
            try
            {
                cmd.CommandText = "EC.updateProduct";
                cmd.Parameters.AddWithValue("@PName", prd.ProductName);
                cmd.Parameters.AddWithValue("@SID", prd.SupplierID);
                cmd.Parameters.AddWithValue("@CID", prd.CategoryID);
                cmd.Parameters.AddWithValue("@Units", prd.Units);
                cmd.Parameters.AddWithValue("@UPrice", prd.UnitPrice);
                cmd.Parameters.AddWithValue("@MRP", prd.MRP);
                cmd.Parameters.AddWithValue("@Discount", prd.Discount);
                cmd.Parameters.AddWithValue("@Picture", prd.Picture);
                cmd.Parameters.AddWithValue("@Rank", prd.Ranking);
                cmd.Parameters.AddWithValue("@PDesc", prd.ProductDesc);
                cmd.Parameters.AddWithValue("@DOM", prd.DOM);
                cmd.Parameters.AddWithValue("@CDesc", prd.CategorygDesc);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productUpdated = true;
                }

                cmd.Connection.Close();
            }
            catch (SupplierException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productUpdated;
        }



        //Method For Deleting a Product Record
        public bool deleteProduct(string productName)
        {
            bool productDeleted = false;
            try
            {
                cmd.CommandText = "EC.deleteProduct";
                cmd.Parameters.AddWithValue("@PName", productName);
                cmd.Connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productDeleted = true;
                }
                cmd.Connection.Close();
            }
            catch (SupplierException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productDeleted;
        }
    }
}
