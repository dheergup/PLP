﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
    
    public class SupplierOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;

        //Method For Adding Suppliers 
        public bool AddSupplier(Supplier sup)
        {
            bool SupplierAdded = false;
            try
            {
                cmd.CommandText = "EC.insertSupplier";
                cmd.Parameters.AddWithValue("@Sid", sup.SupplierID);
                cmd.Parameters.AddWithValue("@Cname", sup.CompanyName);
                cmd.Parameters.AddWithValue("@Address1", sup.Address1);
                cmd.Parameters.AddWithValue("@Address2", sup.Address2);
                cmd.Parameters.AddWithValue("@City", sup.City);
                cmd.Parameters.AddWithValue("@State", sup.State);
                cmd.Parameters.AddWithValue("@PinCode", sup.PostalCode);
                cmd.Parameters.AddWithValue("@Mobile", sup.MobileNo);
                cmd.Parameters.AddWithValue("@Email", sup.EmailId);
                cmd.Parameters.AddWithValue("@Web", sup.Website);
                cmd.Parameters.AddWithValue("@Rank", sup.Ranking);
                cmd.Parameters.AddWithValue("@Note", sup.Note);
                cmd.Parameters.AddWithValue("@Pass", sup.Password);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    SupplierAdded = true;
                }

                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return SupplierAdded;
        }

        //Method For Autogenerating Increamenting SupplierID while Adding new Supplier
        public int supplierID()
        {
            table = new DataTable();
            int SupplierID = 0;

            try
            {
                cmd.CommandText = "EC.getSupplierID";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                DataSet ds = new DataSet();
                ds.Tables.Add(table);
                SupplierID = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
                SupplierID++;
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return SupplierID;
        }

        //Method for Authenticating Supplier 
        public bool authSupplier(int SID, string pass)
        {
            bool SupplierAuthenticated = false;
            try
            {
                cmd.CommandText = "[EC].[authenticateSupplier]";
                cmd.Parameters.AddWithValue("@SID", SID);
                cmd.Parameters.AddWithValue("@Pass", pass);
                cmd.Connection.Open();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    SupplierAuthenticated = true;
                }
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return SupplierAuthenticated;
        }

        //Method For Diplaying All Suppliers 
        public DataTable viewSupplier()
        {
            table = new DataTable();
            try
            {
                cmd = new SqlCommand("EC.viewSupplier");
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }
    }
}
