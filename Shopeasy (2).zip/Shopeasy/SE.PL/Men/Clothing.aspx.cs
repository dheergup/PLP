﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.Data;
using System.Data.SqlClient;
namespace SE.PL.Men
{
    public partial class Clothing : System.Web.UI.Page
    {
        DataTable table;
        CustomerOperations po = new CustomerOperations();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null || Session["User"] == String.Empty)
            {
                Master.Login = true;
                Master.Logout = false;
            }
            else
            {
                Master.UserName = Session["User"].ToString();
                Master.Login = false;
                Master.Logout = true;
            }
        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            if (Session["User"] == null || Session["User"] == String.Empty)
            {
                Response.Write("<script>alert('You are not Logged In\nPlease login');</script>");
                Response.Redirect("/Login.aspx");
            }
            else
            {
                Session["ProductName"] = RadioButtonList1.SelectedItem.Text;
                Response.Redirect("/Order.aspx");
            }
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = po.getProductByName(RadioButtonList1.SelectedItem.Text);
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtPPrice.Visible = true;
                txtPName.Visible = true;
                txtpDesc.Visible = true;
                imageProduct.Visible = true;
                txtPName.Text = ds.Tables[0].Rows[0][1].ToString();
                txtpDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                txtPPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                string base64String = Convert.ToBase64String(data, 0, data.Length);
                imageProduct.ImageUrl = "data:image/png;base64," + base64String;
                btnOrder.Visible = true;
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (CustomException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}