﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.Data;
using System.Data.SqlClient;
namespace SE.PL
{
    public partial class Login : System.Web.UI.Page
    {
        CustomerOperations cp = new CustomerOperations();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string uname = txtUsername.Text;
            string pass = txtPassword.Text;
            DataTable dt = new DataTable();
            dt = cp.searchCustomer(uname, pass);
            if (dt.Rows.Count > 0)
            {
                Session["User"] = txtUsername.Text;
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                Session["Uid"] = ds.Tables[0].Rows[0][0].ToString();
                Response.Redirect("/Homepage.aspx");
            }
            else
            {
                Response.Write("<script>alert('Please enter correct username and password');</script>");
            }
        }
    }
}