﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.DAL;

namespace SE.PL.Admin
{
    public partial class AddSupplier : System.Web.UI.Page
    {
        AdminOperations op=new AdminOperations();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                txtSID.Text = op.supplierID().ToString();
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }    
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Supplier sp = new Supplier();
            
            sp.SupplierID = Convert.ToInt32(txtSID.Text);
            sp.CompanyName = txtCName.Text;
            sp.Address1 = txtAddress1.Text;
            sp.Address2 = txtAddress2.Text;
            sp.City = txtCity.Text;
            sp.State = cmbState.SelectedItem.ToString();
            sp.PostalCode = txtPincode.Text;
            sp.MobileNo = txtMobNo.Text;
            sp.EmailId = txtEmailID.Text;
            sp.Website = txtWebsite.Text;
            sp.Ranking = Convert.ToInt32(txtRanking.Text);
            sp.Note = txtNote.Text;
            sp.Password = txtPassword.Text;

            try
            {
                bool flag = op.AddSupplier(sp);
                if (flag)
                {
                    string message = "Supplier Added Successfully.";
                    string url = "/Admin/AddSupplier.aspx";
                    string script = "window.onload = function(){ alert('";
                    script += message;
                    script += "');";
                    script += "window.location = '";
                    script += url;
                    script += "'; }";
                    ClientScript.RegisterStartupScript(this.GetType(), "Redirect", script, true);
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
              
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            
        }
    }
}